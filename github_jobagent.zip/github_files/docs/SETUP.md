# Setup Guide

Complete instructions for running JobAgent AI in every environment.

---

## Google Colab (Recommended for Students)

Google Colab is free, requires no local installation, and runs directly in your browser.

### Step 1 — Open Colab
Go to [colab.research.google.com](https://colab.research.google.com) and click **New Notebook**.

### Step 2 — Install packages
In the first cell, run:
```python
!pip install anthropic colorama tabulate -q
```

### Step 3 — Add your API key
In a new cell, run:
```python
import os
os.environ["ANTHROPIC_API_KEY"] = "sk-ant-your-key-here"
```

### Step 4 — Upload and run
- Click the 📁 Files icon in the left sidebar
- Click the Upload button and select `job_agent_colab.py`
- In a new cell, run:
```python
exec(open("job_agent_colab.py").read())
```

---

## Local Setup (Windows / Mac / Linux)

### Prerequisites
- Python 3.8 or higher installed
- pip package manager

### Step 1 — Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/jobagent-ai.git
cd jobagent-ai
```

### Step 2 — Create a virtual environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 4 — Configure your API key
```bash
cp .env.example .env
```
Open `.env` in a text editor and replace the placeholder with your real key:
```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxx
```

### Step 5 — Edit your student profile
Open `job_agent_colab.py` and update the `STUDENT` dictionary with your real details:
```python
STUDENT = {
    "name":    "Your Name",
    "email":   "your@email.com",
    "college": "Your College",
    ...
}
```

### Step 6 — Run
```bash
python job_agent_colab.py
```

---

## Getting an Anthropic API Key

1. Visit [console.anthropic.com](https://console.anthropic.com)
2. Click **Sign Up** (free account)
3. Go to **API Keys** in the left menu
4. Click **Create Key** and give it a name like "JobAgent"
5. Copy the key — it starts with `sk-ant-`
6. Paste it into your `.env` file or Colab cell

> The free tier includes enough credits to generate hundreds of cover letters.

---

## Running Without an API Key (Demo Mode)

The agent works fully without an API key — all features run except Claude AI cover letter generation. In demo mode it uses a professional template-based cover letter instead.

No configuration needed — just leave `ANTHROPIC_API_KEY` as `YOUR_API_KEY_HERE` and run normally.

---

## Troubleshooting

| Error | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'tabulate'` | Run `pip install tabulate` |
| `ModuleNotFoundError: No module named 'colorama'` | Run `pip install colorama` |
| `AuthenticationError: Invalid API Key` | Check your key starts with `sk-ant-` and has no extra spaces |
| Colors not showing in Windows CMD | Run `pip install colorama` and restart terminal |
| `SyntaxError: invalid character` | You are trying to run the `.jsx` file — use `job_agent_colab.py` instead |
