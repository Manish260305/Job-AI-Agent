# Contributing to JobAgent AI

Thank you for your interest in contributing! This guide explains how to get involved.

---

## Ways to Contribute

- Report bugs via GitHub Issues
- Suggest new features or platform integrations
- Improve documentation
- Submit pull requests with code improvements

---

## Getting Started

1. Fork the repository on GitHub
2. Clone your fork locally:
   ```bash
   git clone https://github.com/YOUR_USERNAME/jobagent-ai.git
   cd jobagent-ai
   ```
3. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate        # Mac/Linux
   venv\Scripts\activate           # Windows
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env` and add your API key:
   ```bash
   cp .env.example .env
   ```

---

## Submitting a Pull Request

1. Create a branch for your feature:
   ```bash
   git checkout -b feature/add-telegram-notifications
   ```
2. Make your changes and commit clearly:
   ```bash
   git add .
   git commit -m "Add: Telegram notification support for shortlist alerts"
   ```
3. Push your branch and open a Pull Request:
   ```bash
   git push origin feature/add-telegram-notifications
   ```

---

## Code Style

- Follow PEP 8 Python style guidelines
- Use descriptive variable and function names
- Add comments for complex logic
- Keep functions focused — one responsibility per function

---

## Reporting Bugs

Open a GitHub Issue and include:
- Python version
- OS / environment (Colab, local, etc.)
- Steps to reproduce
- Expected vs actual behavior
- Error message or traceback (if any)

---

## Feature Requests

Open a GitHub Issue with the label `enhancement` and describe:
- The problem it solves
- How it should work
- Any relevant examples or references

---

## Priority Contribution Areas

These are areas where contributions are most welcome:

| Area | Description |
|---|---|
| Platform APIs | Real LinkedIn / Naukri / Unstop API integration |
| Email sending | SMTP / SendGrid email dispatch |
| Resume parsing | PDF resume reader for auto-form fill |
| Web UI | Streamlit or Gradio dashboard |
| Scheduling | Cron job / GitHub Actions auto-run |
| Testing | Unit tests and mock data fixtures |

---

All contributors will be credited in the README. Thank you for helping students land their dream jobs!
